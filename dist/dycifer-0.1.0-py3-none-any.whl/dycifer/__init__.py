__version__ = '0.1.0'
__author__ = 'Diogo André Silvares Dias'
__email__ = 'das.dias6@gmail.com'
