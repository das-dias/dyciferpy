def analogDynamicEval(subparser, *args, **kwargs):
    """_summary_
    Dynamic performance evaluation of Analog integrated circuits
    """
    raise NotImplementedError("analogDynamicEval: Not implemented yet.")

def comparatorDynamicEval(subparser, *args, **kwargs):
    """_summary_
    Dynamic performance evaluation of Comparator circuits
    """
    raise NotImplementedError("comparatorDynamicEval: Not implemented yet.")